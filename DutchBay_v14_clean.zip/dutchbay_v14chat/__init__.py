"""DutchBay V14 Chat Package"""
__version__ = "14.0.0-chat"
