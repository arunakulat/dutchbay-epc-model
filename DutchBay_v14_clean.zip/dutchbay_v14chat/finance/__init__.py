"""Finance module"""
