"""Analytics Master Suite for DutchBay EPC Model.

Provides batch scenario processing, KPI calculation, and board-ready Excel reporting.
"""

__version__ = "1.1.0"
