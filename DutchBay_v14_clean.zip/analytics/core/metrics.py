"""KPI Calculation Module for V14 - WACC-Integrated Valuation.

Computes project-level key performance indicators including:
- Project NPV and IRR with explicit discount rates
- Base and prudential valuations
- DSCR series and covenant compliance
- Debt service metrics

PHASE 1 ADDITIONS:
------------------
- Explicit discount_rate and prudential_rate parameters
- Dual NPV calculation (base + prudential)
- WACC transparency fields (discount_rate_used, wacc_label, wacc_is_real)
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Sequence

import numpy_financial as npf

logger = logging.getLogger(__name__)

# Default discount rate fallback
DEFAULT_DISCOUNT_RATE = 0.10


def calculate_scenario_kpis(
    config: Dict[str, Any],
    annual_rows: Sequence[Dict[str, Any]],
    debt_result: Dict[str, Any],
    discount_rate: float,
    prudential_rate: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Calculate comprehensive KPIs for a single scenario with WACC-aware valuation.

    Parameters
    ----------
    config : Dict[str, Any]
        Full scenario configuration (for context/metadata).
    annual_rows : Sequence[Dict[str, Any]]
        Annual cashflow rows from build_annual_rows().
    debt_result : Dict[str, Any]
        Debt layer results from apply_debt_layer().
    discount_rate : float
        Base discount rate (typically WACC nominal) for NPV calculation.
    prudential_rate : Optional[float]
        Prudential discount rate (e.g., WACC + 100 bps) for conservative valuation.
        If provided, calculates npv_prudential.

    Returns
    -------
    Dict[str, Any]
        KPI dictionary containing:
        - project_npv: Base case NPV (float)
        - project_irr: Internal rate of return (float)
        - dscr_series: Annual DSCR values (List[float])
        - min_dscr: Minimum DSCR across all years (float)
        - discount_rate_used: Discount rate applied (float)
        - wacc_label: "base" or "prudential" (str)
        - wacc_is_real: Whether real vs nominal WACC (bool)
        - npv_prudential: Prudential NPV (float, if prudential_rate provided)
        - discount_rate_prudential: Prudential rate used (float, if provided)

    Notes
    -----
    - Project cash flows extracted from annual_rows (cfads_usd).
    - IRR calculated via numpy_financial.irr on CFADS series.
    - DSCR extracted from debt_result if available.
    """
    # -------------------------------------------------------------------------
    # Extract project cash flows (CFADS in USD)
    # -------------------------------------------------------------------------
    project_cf_series: List[float] = []
    for row in annual_rows:
        cfads_usd = row.get("cfads_usd", 0.0)
        # Handle None values
        if cfads_usd is None:
            cfads_usd = 0.0
        project_cf_series.append(float(cfads_usd))

    if not project_cf_series:
        logger.warning("No cash flows found in annual_rows; NPV/IRR will be zero")
        project_cf_series = [0.0]

    # -------------------------------------------------------------------------
    # Calculate Base NPV
    # -------------------------------------------------------------------------
    try:
        project_npv = float(npf.npv(discount_rate, project_cf_series))
    except Exception as exc:
        logger.error("NPV calculation failed: %s", exc)
        project_npv = 0.0

    # -------------------------------------------------------------------------
    # Calculate IRR
    # -------------------------------------------------------------------------
    try:
        project_irr = float(npf.irr(project_cf_series))
        # Handle cases where IRR doesn't converge
        if not (-1.0 <= project_irr <= 10.0):  # Sanity check for reasonable IRR
            logger.warning(
                "IRR calculation returned extreme value (%.2f); setting to 0",
                project_irr,
            )
            project_irr = 0.0
    except Exception as exc:
        logger.warning("IRR calculation failed: %s", exc)
        project_irr = 0.0

    # -------------------------------------------------------------------------
    # Build base result dict
    # -------------------------------------------------------------------------
    result: Dict[str, Any] = {
        "project_npv": project_npv,
        "project_irr": project_irr,
        "discount_rate_used": discount_rate,
        "wacc_label": "base",
        "wacc_is_real": False,  # Caller can override if using real WACC
    }

    # -------------------------------------------------------------------------
    # Calculate Prudential NPV (optional)
    # -------------------------------------------------------------------------
    if prudential_rate is not None:
        try:
            npv_prudential = float(npf.npv(prudential_rate, project_cf_series))
            result["npv_prudential"] = npv_prudential
            result["discount_rate_prudential"] = prudential_rate
            logger.debug(
                "Prudential NPV calculated: %.0f at %.2f%% discount rate",
                npv_prudential,
                prudential_rate * 100,
            )
        except Exception as exc:
            logger.warning("Prudential NPV calculation failed: %s", exc)
            result["npv_prudential"] = 0.0
            result["discount_rate_prudential"] = prudential_rate

    # -------------------------------------------------------------------------
    # Extract DSCR series from debt_result
    # -------------------------------------------------------------------------
    dscr_series = debt_result.get("dscr_series", [])
    if not dscr_series:
        logger.warning("No DSCR series found in debt_result")
        dscr_series = []

    result["dscr_series"] = dscr_series

    # Calculate minimum DSCR
    if dscr_series:
        # Filter out None, NaN, and infinite values
        valid_dscrs = [
            d for d in dscr_series
            if d is not None and isinstance(d, (int, float)) and -1e6 < d < 1e6
        ]
        if valid_dscrs:
            min_dscr = float(min(valid_dscrs))
        else:
            logger.warning("No valid DSCR values found; setting min_dscr to 0")
            min_dscr = 0.0
    else:
        min_dscr = 0.0

    result["min_dscr"] = min_dscr

    # -------------------------------------------------------------------------
    # Additional debt metrics (if available)
    # -------------------------------------------------------------------------
    # LLCR (Loan Life Cover Ratio) - if present in debt_result
    if "llcr" in debt_result:
        result["llcr"] = debt_result["llcr"]

    # PLCR (Project Life Cover Ratio) - if present
    if "plcr" in debt_result:
        result["plcr"] = debt_result["plcr"]

    # Covenant breach flags
    covenant_breaches = debt_result.get("covenant_breaches", [])
    result["covenant_breach_count"] = len(covenant_breaches)
    result["covenant_breaches"] = covenant_breaches

    # -------------------------------------------------------------------------
    # Logging summary
    # -------------------------------------------------------------------------
    logger.debug(
        "KPIs calculated: NPV=%.0f | IRR=%.2f%% | Min DSCR=%.2fx | Discount=%.2f%%",
        project_npv,
        project_irr * 100,
        min_dscr,
        discount_rate * 100,
    )

    if prudential_rate is not None and "npv_prudential" in result:
        logger.debug(
            "Prudential metrics: NPV=%.0f at %.2f%% discount",
            result["npv_prudential"],
            prudential_rate * 100,
        )

    return result
