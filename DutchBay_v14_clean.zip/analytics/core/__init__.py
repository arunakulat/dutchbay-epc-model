"""Core analytics modules for financial calculations and metrics."""
# analytics/__init__.py

__version__ = "1.1.0"