# dutchbay_v13/__main__.py
from __future__ import annotations

from .cli import main as _main

if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(_main())

    